# Drosera Node Template

Template proyek Firebase Functions dengan Node.js, siap dijalankan di GitHub Codespaces dan Drosera CLI.
